#import <Foundation/Foundation.h>

@interface NSDate (Utilities)
+ (NSDate *)dateFromZuluTimeString:(NSString *)string;
@end
