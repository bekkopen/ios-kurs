#import <SenTestingKit/SenTestingKit.h>

@interface libraryTests : SenTestCase

@end
